enum ScheduleType {
  multipleTimesDaily,
  oneTime,
}