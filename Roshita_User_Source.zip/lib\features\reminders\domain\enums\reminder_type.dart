enum ReminderType {
  medication,
  appointment,
}